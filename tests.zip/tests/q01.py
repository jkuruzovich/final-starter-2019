test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cost_ma == 17.906257207081175
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> cost_ny==15.188246329742485
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
