test = {
  'name': '2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> splittest1
          (72930, 40)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
