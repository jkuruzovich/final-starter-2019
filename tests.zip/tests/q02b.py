test = {
  'name': '2b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> splittest2
          0
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
