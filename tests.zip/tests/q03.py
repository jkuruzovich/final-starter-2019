test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> r2_train_cost
          0.6964551409590365
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> r2_test_cost
          0.6983619671189338
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
