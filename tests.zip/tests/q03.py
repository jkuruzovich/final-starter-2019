test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> r2_train_cost
          0.51460627323440655
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> r2_test_cost
          0.5025649808816941
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
