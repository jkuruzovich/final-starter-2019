test = {
  'name': '2c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> "{0:.4f}".format(round( r2_train_cost,4))
          '0.6965'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
