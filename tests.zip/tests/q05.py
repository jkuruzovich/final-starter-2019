test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> total_high_cost_ny
          21558
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> total_high_cost_ma
          22505
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
