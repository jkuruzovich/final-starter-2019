test = {
  'name': '5a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> total_high_cost_ny
          21558
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
