test = {
  'name': '6b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> splittest4
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
