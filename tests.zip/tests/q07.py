test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> train_accuracy
          0.88490333196215554
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> test_accuracy
          0.88178269772203732
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
