test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> train_accuracy
          0.8849033319621555
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> test_accuracy
          0.6964551409590365
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
