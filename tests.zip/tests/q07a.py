test = {
  'name': '7a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> "{0:.4f}".format(round( train_accuracy,4))
          '0.9087'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
