test = {
  'name': '7b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> "{0:.4f}".format(round( test_accuracy,4))
          '0.8818'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
